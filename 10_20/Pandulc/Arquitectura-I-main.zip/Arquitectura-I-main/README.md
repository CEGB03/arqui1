# Proyecto Integrador 
## Arquitectura de Computadoras I

Proyecto correspondiente a la materia Arquitectura de Computadoras I, basado en la implementacion de un programa en assembly para el manejo de la placa DE0-nano

### Integrantes

![MattGoode7](https://github.com/MattGoode7.png?size=70) [Matias Carrizo](https://github.com/MattGoode7)

![Pandulc](https://github.com/Pandulc.png?size=70) [Gabriel Guillaumet](https://github.com/Pandulc)